package com.capg.exception;

public class InValidAmountException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InValidAmountException(final String msg)
    {
        super(msg);
    }

    public InValidAmountException(final String msg,final Throwable exc){
        super(msg,exc);
    }

}
