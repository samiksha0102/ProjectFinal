export class Customer{
    caccount:number;
    cname:string;
    cphone:number;
    cpassword:string;
    ccity:string;
    cbalance:number;
  
      constructor(caccount:number,cname:string,cphone:number,cpassword:string,ccity:string,cbalance:number)
      {
        this.cbalance=cbalance;
        this.caccount=caccount;
        this.cname=cname;
        this.cphone=cphone;
        this.cpassword=cpassword;
        this.ccity=ccity;
      }
  }