package com.capg.exception;

public class IncorrectMobileNo extends Exception 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
