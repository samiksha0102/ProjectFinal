package com.capg.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.entity.Bank;

import com.capg.exception.IncorrectAccountNoException;
import com.capg.service.BankService;

public class BankUI {
	long accNo;
	ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
	BankService service = context.getBean(BankService.class);

	public void show2() {
		System.out.println();
		System.out.println("**************************************************************************************");
		
		System.out.println(" Enter Your Choice ");
		System.out.println("1. Account Details ");
		System.out.println("2. Show Balance ");
		System.out.println("3. Deposit Balance ");
		System.out.println("4. Withdraw Balance ");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transaction ");
		System.out.println("7. Back To Previous Menu ");
		System.out.println("8. Exit ");
		System.out.println("***************************************************************************************");
	}

	public void show1() {
		System.out.println("******************************************************************");
		
		System.out.println("1. Yes ");
		System.out.println("2. No ");
		
	}

	public int getOption(Scanner scanner) {
		try {
			int opt = scanner.nextInt();
			return opt;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public void choose2(long accNo) {
		boolean run = true;
		while (run) {
			show2();
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter Your Choice: ");
			int opt = getOption(sc);

			if (opt == -1) {
				run = false;
			}

			Bank bean = service.getBankDetails(accNo);

			switch (opt) {
			case 1:
				try {
					System.out.println("*****************************************************************");

					System.out.println("____________________ACCOUNT DETAILS_____________________________");
				
					System.out.println("Name                :  " + bean.getName());
					System.out.println("Account Number      :  " + accNo);
					System.out.println("Address             :  " + bean.getAddress());
					System.out.println("Mobile No           :  " + bean.getMobNo());
					System.out.println("*****************************************************************");
				} catch (Throwable e) {
					System.out.println(" Account Doesn't Exist " );
				}
				break;

			case 2:
				try {
					System.out.println("***********************************************************************");
					System.out.println("________________________BALANCE_________________________________");
					System.out.println();
					System.out.println("Balance  :  " + bean.getBal());
					System.out.println("************************************************************************");
				} catch (Throwable e) {
					System.out.println(" Balance Not Found ");
				}
				break;

			case 3:
				try {
					System.out.println("**************************************************************************");
					System.out.println("______________________DEPOSIT____________________________");
					System.out.println();
					System.out.println("Available Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount to Deposit : ");
					double dept = sc.nextDouble();
					double currBal = service.depositBalance(accNo, dept);
					System.out.println("New Balance	:" + currBal);
					System.out.println("************************************************************************");
				} catch (Throwable e) {
					System.out.println("Account Doesn't Exist");
				}
				break;

			case 4:
				try {
					System.out.println("*************************************************************************");
					System.out.println("______________________WITHDRAW_________________________________");
					System.out.println();
					System.out.println("Available Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount to WithDraw : ");
					double wid = sc.nextDouble();
					double currBal = service.withdrawBalance(accNo, wid);
					System.out.println("New Balance	:" + currBal);
					System.out.println("**************************************************************************");
				} catch (Throwable e) {
					System.out.println(e);
				}
				break;

			case 5:
				try {
					System.out.println("***************************************************************************");
					System.out.println("________________________FUND TRANSFER___________________________");
					System.out.println();
					System.out.println("Available Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount  to Transfer : ");
					double amt1 = sc.nextDouble();
					double amt = bean.getBal();
					if (amt1 > amt) {
						System.out.println(" Fetched amount can't be more than available balance !! ");
					} else {
						System.out.print("Enter the Account No of Receiver: ");
						long accNo2 = sc.nextLong();
						service.getBankDetails1(accNo2);
						double currBal = service.fundTransfer(accNo, accNo2, amt1);
						System.out.println("New Balance	:" + currBal);
					}
				} catch (Throwable e) {
					System.out.println( "Account Not Found");
				}
				break;

			case 6:
				try {
					System.out.println("***************************************************************************");
					System.out.println("_________________PRINT TRANSACTION_____________________________");
					System.out.println();
					service.printTransaction(accNo);
				    System.out.println("****************************************************************************");
				} catch (Throwable e) {
					System.out.println("  Transactions Not Found" );
				}
				break;

			case 7:
				System.out.println("******************************************************************************");
				choose1();

				break;

			case 8:
				System.out.println();
				System.out.println("Thanks for visiting !!!!!!!!!!");
				System.exit(0);
				break;

			default: {
				run = false;
				System.out.println("BYE!!!!!!");
				System.exit(0);
			}

			}
		}

	}

	long genAccNo;

	public void choose1() {
		int s;
		String opt1;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("**************************************************************************");
			System.out.print("Enter '1' if you are an Existing User else Enter '2' : ");
			System.out.println();
			show1();
			System.out.print("WHAT'S YOUR CHOICE ?:");
			opt1 = sc.next();
			s = service.validateInput1(opt1);
		} while (s != 1);
		int result = Integer.parseInt(opt1);
		switch (result) {
		case 1:
			try {
				
				System.out.print(" Enter your Account No : ");
				accNo = sc.nextLong();
				Bank bean= service.getBankDetails(accNo);
				System.out.print("Enter your Password  : ");
				String pwd = sc.next();
				String pwd1 = bean.getPwd();
				if (pwd.equals(pwd1)) {
					System.out.println();
					System.out.println("Welcome Back, " + bean.getName());
				} else {
					System.out.println("Invalid Password.. Try Again!!");
					System.out.println();
					choose1();
				}
				choose2(accNo);
			} catch (IncorrectAccountNoException e) {
				System.out.println("Account Number is Not Valid");
				choose1();
			} catch (Throwable e) {
				System.out.println("Account Not Found" );
				choose1();
			}

			break;

		case 2:

			try {
				System.out.println();
				System.out.println("__________________Create New Account_____________________");
				System.out.println();
				System.out.println("");

				String name;
				int w2 = 0;
				do {
					System.out.println("Enter Your Name :");
					name = sc.next();
					w2 = service.checkName(name);
				} while (w2 != 1);

				

				String pwd;
				int w1 = 0;
				do {
					System.out.println("Choose a Password :");
					pwd = sc.next();
					w1 = service.checkPwd(pwd);
				} while (w1 != 1);

				
				String mobNo;
				int w = 0;
				do {
					System.out.println("Enter Your Mobile No :");
					mobNo = sc.next();
					w = service.checkMobNo(mobNo);
				} while (w != 1);

				System.out.println("Enter Your Address :");
				String add = sc.next();
				System.out.println("********************************0");
				double initBal = 6000;
				genAccNo = service.createAccount(pwd, name, add, initBal, mobNo);
				

				if (genAccNo > 0) {
					System.out.println("Account Created!!!");
					System.out.println("Generated Account No :" + genAccNo);
					System.out.println("********************************************************************");
					choose2(genAccNo);
				} else {
					System.out.println("Sorry You are not an elligible user!!!");
				}

			} catch (Throwable e) {
				System.out.println("****************************" + e.getMessage());
				System.out.println("Unable To Create Account" + e);
				choose2(genAccNo);
			}
			break;

		default:
			System.out.println("BYE");

		}
		sc.close();
	}

	public static void main(String[] args) {
		System.out.println("__________________________________________________________");
		
		System.out.println("*******************  XYZ BANK ****************************");
		System.out.println("__________________________________________________________");
		BankUI ui = new BankUI();
		ui.choose1();
	}
}
