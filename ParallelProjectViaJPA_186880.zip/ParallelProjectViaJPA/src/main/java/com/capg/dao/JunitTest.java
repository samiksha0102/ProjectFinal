package com.capg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.service.BankService;

public class JunitTest {

	private static final double DELTA = 1e-15;

	ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
	BankService service = context.getBean(BankService.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Test
	public void test() {

		/**
		 * test uses 1) Account no=1 2) previous balance = 8000 3) Amount Deposit = 100
		 * 4) expected result=8100
		 */

		double availBal = service.depositBalance(52, 100);
		double expectedBal = 6600;
		Assert.assertEquals(expectedBal, availBal, DELTA);

		/**
		 * Restoring Old State
		 */
		service.withdrawBalance(52, 100);

	}

}
