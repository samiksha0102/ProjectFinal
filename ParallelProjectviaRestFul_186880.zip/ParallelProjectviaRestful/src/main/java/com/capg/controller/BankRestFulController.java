package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.entity.Bank;
import com.capg.entity.Transaction;
import com.capg.exception.AccountNotFoundException;
import com.capg.service.IBankService;


@RestController
@RequestMapping("/bank")
public class BankRestFulController {
	@Autowired
	IBankService service;

	@PostMapping("/createAccount")
	public List<Bank> createAccount(@RequestBody Bank bean) {
		return service.createAccount(bean);
	}

	@GetMapping("/accountDetails/{accNo}")
	public Bank accountDetails(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.accountDetails(accNo);
	}

	@GetMapping("/showBalance/{accNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNo) throws AccountNotFoundException {
		Double bal = service.showBalance(accNo);
		return new ResponseEntity<String>("Available Balance is " + bal, HttpStatus.OK);
	}

	@PutMapping("/depositBalance/{accNo}/{amt}")
	public ResponseEntity<String> deposit(@PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		Double bal = service.depositBalance(accNo, amt);
		return new ResponseEntity<String>("Available  Balance is " + bal, HttpStatus.OK);
	}

	@PutMapping("/withdrawBalance/{accNo}/{amt}")
	public ResponseEntity<String> withdraw(@PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		Double bal = service.withdrawBalance(accNo, amt);
		return new ResponseEntity<String>("Available Balance is " + bal, HttpStatus.OK);
	}

	@PutMapping("/fundTransfer/{accNo1}/{amt}/{accNo2}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long accNo1, @PathVariable Double amt,
			@PathVariable Long accNo2) throws AccountNotFoundException {
		Double bal = service.fundTransfer(accNo1, amt, accNo2);
		return new ResponseEntity<String>("Available  Balance is " + bal, HttpStatus.OK);
	}

	@GetMapping("/printTransaction/{accNo}")
	public List<Transaction> printTransaction(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.printTransaction(accNo);
	}
	@ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<String> accountNotFound(AccountNotFoundException e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

}
