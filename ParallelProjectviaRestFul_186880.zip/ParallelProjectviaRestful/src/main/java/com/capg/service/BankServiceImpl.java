package com.capg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.IBankDao;
import com.capg.dao.ITransDao;
import com.capg.entity.Bank;
import com.capg.entity.Transaction;
import com.capg.exception.AccountNotFoundException;



@Service
public class BankServiceImpl implements IBankService {
	@Autowired
	IBankDao bDao;

	@Autowired
	ITransDao tDao;

	@Override
	public List<Bank> createAccount(Bank bean) {
		bDao.save(bean);
		return bDao.findAll();
	}

	@Override
	public Bank accountDetails(Long accNo)throws AccountNotFoundException {
		if(bDao.existsById(accNo)) {
		return bDao.findById(accNo).get();}
		else {
			 throw new AccountNotFoundException("This Account Doesn't exists");
		}
	}

	@Override
	public List<Transaction> printTransaction(Long accNo)throws AccountNotFoundException {
		if(tDao.existsById(accNo)) {
		 return   tDao.printTransaction(accNo);}
		else {
			 throw new AccountNotFoundException("This Account Doesn't exists");
		}
		
	}

	@Override
	public Double fundTransfer(Long accNo1, Double amt, Long accNo2)throws AccountNotFoundException {
		if (bDao.existsById(accNo1)&&(bDao.existsById( accNo2))) {
		Optional<Bank> bean1 = bDao.findById(accNo1);
		Optional<Bank> bean2 = bDao.findById(accNo2);
		if (bean1.isPresent() && bean2.isPresent()) {
			Bank temp = bean1.get();
			
			temp.setBal(bean1.get().getBal() - amt);
			bDao.save(temp);
			Bank temp2 = bean2.get();
			temp2.setBal(bean2.get().getBal() + amt);
			bDao.save(temp2);
			Transaction trans = new Transaction(accNo1, "Fund Transfer", bean1.get().getBal()+amt,
					bean1.get().getBal());
			tDao.save(trans);
			Transaction trans2 = new Transaction(accNo2, "Fund Recieved", bean2.get().getBal(),
					amt + bean2.get().getBal());
			tDao.save(trans2);
			return showBalance(accNo1);
		} else {
			return showBalance(accNo1);
		}}
		else   throw new AccountNotFoundException("This Account Doesn't exists");
	}

	@Override
	public Double withdrawBalance(Long accNo, Double amt)throws AccountNotFoundException {
		if(bDao.existsById(accNo)) {
		Optional<Bank> bean = bDao.findById(accNo);
		if (bean.isPresent()) {
			Bank temp = bean.get();
			temp.setBal(bean.get().getBal() - amt);
			bDao.save(temp);
			Transaction trans = new Transaction(accNo, "Withdraw", bean.get().getBal()+amt,
					bean.get().getBal());
			tDao.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}}
		else {
			 throw new AccountNotFoundException("This Account Doesn't exists");
		}
	}

	@Override
	public Double depositBalance(Long accNo, Double amt)throws AccountNotFoundException {
		if(bDao.existsById(accNo)) {
		Optional<Bank> bean = bDao.findById(accNo);
		if (bean.isPresent()) {
			Bank temp = bean.get();
			temp.setBal(bean.get().getBal() + amt);
			bDao.save(temp);
			Transaction trans = new Transaction(accNo, "Deposit", bean.get().getBal()-amt,
					bean.get().getBal());
			tDao.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}}
		else {
			throw new AccountNotFoundException("This Account Doesn't exists");
		}
	}

	@Override
	public Double showBalance(Long accNo)throws AccountNotFoundException {
		if(bDao.existsById(accNo)) {Double bal = bDao.findById(accNo).get().getBal();
		return bal;}
		else {
			throw new AccountNotFoundException("This Account Doesn't exists");
		}
	}

}
