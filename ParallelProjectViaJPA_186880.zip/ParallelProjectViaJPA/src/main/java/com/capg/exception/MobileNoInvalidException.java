package com.capg.exception;

public class MobileNoInvalidException extends Exception 
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MobileNoInvalidException(final String msg)
	    {
	        super(msg);
	    }

	    public MobileNoInvalidException(final String msg,final Throwable exc){
	        super(msg,exc);
	    }

}
