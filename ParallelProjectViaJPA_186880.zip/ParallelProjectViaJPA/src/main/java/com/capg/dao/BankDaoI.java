package com.capg.dao;

import com.capg.entity.Bank;

public interface BankDaoI {

	Bank getBankDetails(long accNo);

	Bank getBankDetails1(long accNo2);

	double depositBalance(long accNo, double dept);

	double fundTransfer(long accNo, long accNo2, double transAmt);

	boolean createAccount(Bank entity);

	void printTransaction(long accNo);

	double withdrawBalance(long accNo, double wid);

}
