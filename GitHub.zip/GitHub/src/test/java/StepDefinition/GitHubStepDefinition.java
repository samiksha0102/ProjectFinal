package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubStepDefinition {
	private WebDriver driver;
	private WebElement searchBox1;
	private WebElement searchBox2;
	String userId;
	String password;
	
	
	@Given("^User is on GitHub Login Page$")
	public void user_is_on_GitHub_Login_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sameerkh\\BDDTesting\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://github.com/login");
	    Thread.sleep(5000);
	}

	@When("^User enters login credintials$")
	public void user_enters_login_credintials() throws Throwable {
		searchBox1 = driver.findElement(By.xpath("//input[@name='login']"));
		searchBox2 = driver.findElement(By.xpath("//input[@name='password']"));
	    
	}

	@Then("^He get's logged in$")
	public void he_get_s_logged_in() throws Throwable {
		searchBox1.sendKeys("Id");
		searchBox2.sendKeys("Password");
	    searchBox2.submit();
	    Thread.sleep(20000);
	    driver.quit();
	    
	}

}
