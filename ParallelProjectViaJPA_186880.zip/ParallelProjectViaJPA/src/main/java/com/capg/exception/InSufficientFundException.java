package com.capg.exception;

public class InSufficientFundException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InSufficientFundException(final String msg)
    {
        super(msg);
    }

    public InSufficientFundException(final String msg,final Throwable exc){
        super(msg,exc);
    }

}
