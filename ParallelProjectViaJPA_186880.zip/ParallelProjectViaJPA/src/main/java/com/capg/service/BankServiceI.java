package com.capg.service;

import com.capg.entity.Bank;

public interface BankServiceI {

	int validateInput1(String option1);

	Bank getBankDetails(long accNo);

	Bank getBankDetails1(long accNo2);

	double depositBalance(long accNo, double dep);

	double withdrawBalance(long accNo, double with);

	double fundTransfer(long accNo, long accNo2, double amt1);

	long createAccount(String pwd, String name, String add, double bal, String mobNo);

	void printTransaction(long accNo);

	int checkName(String name);

	int checkMobNo(String mobNo);

	int checkPwd(String pwd);

}
