import { Component, OnInit, APP_INITIALIZER, ɵConsole } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';
import { Alert } from 'selenium-webdriver';

@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;

  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositeAmount(data:any){
    let tid=Math.floor(Math.random() *21) +6582 ;
    let caccount_first=this.service.loginAccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Deposite Amount"
    this.service.depositeBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions(tid,caccount_first,0,cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
     }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
