package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.BankDaoI;
import com.capg.entity.Bank;
import com.capg.exception.IncorrectAccountNoException;

@Service("service")

public class BankService implements BankServiceI {

	@Autowired
	private BankDaoI dao;

	public void setBankDaoI(final BankDaoI dao) {
		this.dao = dao;
	}

	public BankService(final BankDaoI dao) {
		this.dao = dao;
	}

	public void validateAccNo(long accNo) {
		if (accNo < 0) {
			throw new IncorrectAccountNoException("Incorrect Account No.");
		}
	}

	public int validateNewNo(String mobNo) {
		if (!(mobNo.length() == 10)) {
			System.out.println("Mobile No Should Be Of 10 Digits");
			System.out.println();
			return 0;
		} else if (mobNo.matches("[0-9]*")) {
			return 1;

		} else {
			System.out.println("Mobile No Can Not Contain Characters");

			return 0;

		}
	}

	public int checkMobNo(String mobNo) {
		int a1 = validateNewNo(mobNo);
		return a1;
	}

	public long createAccount(String pwd, String name, String add, double bal, String mobNo) {
		boolean res = false;
		Bank bean = new Bank();
		bean.setPwd(pwd);
		bean.setName(name);
		bean.setAddress(add);
		bean.setBal(bal);
		bean.setMobNo(mobNo);
		res = dao.createAccount(bean);
		if (res)
			return bean.getAccNo();
		else
			return 0;
	}

	public int validateName(String name) {
		if (name.matches("[A-Z][a-z]*"))
			return 1;
		else {
			System.out.println("First Name Should Not Contain Numbers and first letter should be Capital");
			System.out.println();
			return 0;
		}

	}

	
	public int validatePwd(String pwd) {
		if (pwd.length() >= 8)
			return 1;
		else {
			System.out.println("Password Should be to AtLeast 8 Characters");
			System.out.println();
			return 0;
		}
	}

	public int checkPwd(String pwd) {
		int a1 = validatePwd(pwd);
		return a1;
	}

	public Bank getBankDetails(final long accNo) {
		validateAccNo(accNo);
		return dao.getBankDetails(accNo);
	}

	public Bank getBankDetails1(final long accNo2) {
		validateAccNo(accNo2);
		Bank bean= dao.getBankDetails1(accNo2);
		return bean;
	}

	public double depositBalance(long accNo, double dept) {
		double currBal = dao.depositBalance(accNo, dept);
		return currBal;
	}

	public double withdrawBalance(long accNo, double wid) {
		double currBal = dao.withdrawBalance(accNo, wid);
		return currBal;
	}

	public double fundTransfer(long accNo, long accNo2, double amt1) {
		double currBal = dao.fundTransfer(accNo, accNo2, amt1);
		return currBal;
	}

	public void printTransaction(long accNo) {
		dao.printTransaction(accNo);
	}

	public int validateInput1(String opt1) {
		if (opt1.matches("[1-2]"))
			return 1;
		else {
			System.out.println();
			System.out.println("Input MissMatch!!!!! Enter Again!!!!!!");
			return 0;

		}

	}

	

	


	public int checkName(String name) {
		int name1 = validateName(name);
		return name1;
	}

	public void printTrans(long accNo) {
		// TODO Auto-generated method stub
		
	}

	

	

}
