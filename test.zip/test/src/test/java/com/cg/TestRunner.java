package com.cg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\samijain\\BDD\\test\\src\\test\\resources\\SearchFeature.feature" ,glue="com.cg1")
public class TestRunner {

}
