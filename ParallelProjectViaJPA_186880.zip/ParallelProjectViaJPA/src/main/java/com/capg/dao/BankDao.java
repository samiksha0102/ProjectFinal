package com.capg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.entity.Bank;
import com.capg.entity.Transaction;

@Repository
@Transactional
public class BankDao implements BankDaoI {

	@PersistenceContext
	private EntityManager entityManager;

	public boolean createAccount(Bank bean) {
		entityManager.persist(bean);
		return true;
	}

	public Bank getBankDetails(final long accNo) {
		return entityManager.find(Bank.class, accNo);
	}

	public Bank getBankDetails1(final long accNo2) {
		return entityManager.find(Bank.class, accNo2);
	}

	public double depositBalance(final long accNo, final double dept) {
		Transaction trans = new Transaction();
		Bank bean = getBankDetails(accNo);
		double initBal = bean.getBal();
		double currBal = initBal + dept;
		bean.setBal(currBal);
		trans.setAccno(accNo);
		trans.setTransType("Deposit");
		trans.setPreviousBal(initBal);
		trans.setCurrentBal(currBal);
		entityManager.persist(trans);
		entityManager.merge(bean);
		return currBal;

	}

	public double withdrawBalance(final long accNo, final double wid) {

		Bank bean = getBankDetails(accNo);
		double initBal = bean.getBal();
		double currBal = initBal;
		if (wid > initBal) {
			System.out.println("Withdraw Amount can not be more than Available Balance!! ");
		} else {

			currBal = initBal - wid;
			bean.setBal(currBal);
			Transaction trans = new Transaction();
			trans.setAccno(accNo);
			trans.setTransType("WithDraw");
			trans.setPreviousBal(initBal);
			trans.setCurrentBal(currBal);
			entityManager.persist(trans);
			entityManager.merge(bean);
		}
		return currBal;
	}

	public void printTransaction(long accNo) {

		TypedQuery<Transaction> q1 = entityManager.createQuery("select q from Transaction q", Transaction.class);

		List<Transaction> l1 = q1.getResultList();

		System.out.println("TransNo      TransType          PrevBal          AvailBal");
		System.out.println();

		for (Transaction t1 : l1) {
			long acc = t1.getAccno();
			if (acc == accNo) {
				System.out.println(t1.getTransNo() + "            " + t1.getTransType() + "        "
						+ t1.getPreviousBal() + "        " + t1.getCurrentBal());
			}
		}

	}

	public double fundTransfer(long accNo, long accNo2, double amt1) {

		Transaction trans = new Transaction();
		Bank bean = getBankDetails(accNo);
		double initBal = bean.getBal();
		double currBal = initBal;

		if (amt1 > initBal)

		{
			System.out.println("Transfer Amount can not be more than Available Balance!! ");
		} else {

			currBal = initBal - amt1;
			bean.setBal(currBal);
			entityManager.merge(bean);

			Bank bean1 = getBankDetails(accNo2);
			double initBal2 = bean1.getBal();
			double currBal2 = initBal2 + amt1;
			bean1.setBal(currBal2);
			entityManager.merge(bean1);
			trans.setAccno(accNo2);
			trans.setTransType("Fund Received");
			trans.setPreviousBal(initBal2);
			trans.setCurrentBal(currBal2);
			entityManager.persist(trans);

			trans.setAccno(accNo);
			trans.setTransType("Fund Transfer");
			trans.setPreviousBal(initBal);
			trans.setCurrentBal(currBal);
			entityManager.persist(trans);

		}

		return currBal;

	}

}
