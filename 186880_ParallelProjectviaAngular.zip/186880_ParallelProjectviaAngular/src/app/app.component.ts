import { Component } from '@angular/core';
import { MyServiceService } from './Service/my-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'routing';

  message:string;

  constructor(private check: MyServiceService) { }

  ngOnInit() {
    this.check.currentMessage.subscribe(message => this.message = message)
  }

}
