import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Models/Customer';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  withdrawAmount(data:any){
    let tid=Math.floor(Math.random() *10) +7985 ;
    let caccount_first=this.service.loginAccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Withdraw Amount"
    this.service.withdrawBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions(tid,caccount_first,0,cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
     }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }
}
