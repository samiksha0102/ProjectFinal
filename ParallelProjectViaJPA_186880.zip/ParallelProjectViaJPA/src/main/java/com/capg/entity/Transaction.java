package com.capg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="transaction1")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "b")
	@SequenceGenerator(name = "b", sequenceName = "transsq1")
	@Column(length = 20)
	private int transNo;
	@Column(length = 20)
	private long accno;
	@Column(length = 20)
	private String transType;
	@Column(length = 20)
	private double previousBal;
	@Column(length = 20)
	private double currentBal;

	public int getTransNo() {
		return transNo;
	}

	public void setTransNo(int transNo) {
		this.transNo = transNo;
	}

	public long getAccno() {
		return accno;
	}

	public void setAccno(long accno) {
		this.accno = accno;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public double getPreviousBal() {
		return previousBal;
	}

	public void setPreviousBal(double previousBal) {
		this.previousBal = previousBal;
	}

	public double getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(double currentBal) {
		this.currentBal = currentBal;
	}

	@Override
	public String toString() {
		return "Transaction [transNo=" + transNo + ", accno=" + accno + ", transType=" + transType
				+ ", previousBal=" + previousBal + ", currentBal=" + currentBal + "]";
	}

	public Transaction(int transNo, long accno, String transType, double previousBal, double currentBal) {
		super();
		this.transNo = transNo;
		this.accno = accno;
		this.transType = transType;
		this.previousBal = previousBal;
		this.currentBal = currentBal;
	}

	public Transaction() {
		super();
	}

}



/*
create sequence transsq1
start with 100
maxvalue 10000
increment by 1
cycle;

*/

